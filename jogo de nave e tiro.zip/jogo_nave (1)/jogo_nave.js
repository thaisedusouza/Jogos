// --- Lógica do Jogo em JavaScript (Versão Modificada) ---
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// --- Configurações do Jogo ---
const MIN_ENEMY_SIZE = 60;
const MAX_ENEMY_SIZE = 90;
const BULLET_COLOR = '#ff3399';
const BULLET_SIZE = 8;
const SCORE_COLOR = '#ffb3ff';

// --- Novas Configurações (Efeitos) ---
const PARTICLE_COUNT = 30; // 30 partículas por explosão
const PARTICLE_SPEED = 4;
const PARTICLE_LIFE = 60; // 60 frames (1 segundo)
const STAR_COUNT = 200;

// --- Sons do Jogo ---
const sounds = {
    tiro: new Audio('tiro.mp3'),
    explosao: new Audio('explosao.mp3'),
    gameOver: new Audio('game_over.mp3')
};

// Ajuste o volume
Object.values(sounds).forEach(sound => {
    sound.volume = 0.1;
});

let score = 0;
let gameOver = false;

// --- Imagens dos Inimigos ---
const enemyImages = [
    { src: 'inimigo1.png', img: new Image() },
    { src: 'inimigo2.png', img: new Image() },
    { src: 'inimigo3.gif', img: new Image() },
    { src: 'inimigo4.gif', img: new Image() }
];

enemyImages.forEach(enemy => {
    enemy.img.src = enemy.src;
    enemy.img.onload = () => enemy.loaded = true;
    enemy.img.onerror = () => console.warn(`Não foi possível carregar ${enemy.src}`);
});

// --- Jogador (Nave) ---
const player = {
    x: canvas.width / 2 - 25,
    y: canvas.height - 60,
    width: 60,
    height: 60,
    speed: 7,
    dx: 0,
    dy: 0,
    color: '#ff69b4'
};

// --- Imagem da Nave ---
const playerImage = new Image();
playerImage.src = 'nave_verde.png';
let playerImageLoaded = false;
playerImage.onload = function() {
    playerImageLoaded = true;
};
playerImage.onerror = function() {
    console.warn('Não foi possível carregar nave_verde.png. Usando fallback retângulo.');
};

// --- Arrays do Jogo ---
const bullets = [];
const enemies = [];
const stars = []; // NOVO: Array para estrelas
const particles = []; // NOVO: Array para explosões
const bulletSpeed = 10;
const enemySpeed = 2;

// --- Funções de Desenho ---

function drawPlayer() {
    ctx.save();
    if (playerImageLoaded) {
        // Adiciona brilho ao redor da nave
        const gradient = ctx.createRadialGradient(
            player.x + player.width/2, player.y + player.height/2, 0,
            player.x + player.width/2, player.y + player.height/2, player.width/1.5
        );
        gradient.addColorStop(0, 'rgba(255, 255, 255, 0.2)');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.fillRect(player.x - 10, player.y - 10, player.width + 20, player.height + 20);
        
        // --- NOVO: Efeito de Propulsor (Flicker) ---
        const thrusterX = player.x + player.width / 2;
        // Posiciona o propulsor um pouco acima da base para sobrepor a imagem
        const thrusterY = player.y + player.height - 5; 
        const thrusterHeight = 15 + Math.random() * 10;
        const thrusterWidth = 8 + Math.random() * 4;

        const thrusterGradient = ctx.createLinearGradient(thrusterX, thrusterY, thrusterX, thrusterY + thrusterHeight);
        thrusterGradient.addColorStop(0, 'rgba(255, 220, 0, 0.9)'); // Amarelo
        thrusterGradient.addColorStop(0.5, 'rgba(255, 100, 0, 0.6)'); // Laranja
        thrusterGradient.addColorStop(1, 'transparent');
        
        ctx.fillStyle = thrusterGradient;
        ctx.beginPath();
        // Desenha um triângulo para o fogo
        ctx.moveTo(thrusterX - thrusterWidth / 2, thrusterY);
        ctx.lineTo(thrusterX + thrusterWidth / 2, thrusterY);
        ctx.lineTo(thrusterX, thrusterY + thrusterHeight);
        ctx.closePath();
        ctx.fill();
        // --- Fim do Propulsor ---

        ctx.drawImage(playerImage, player.x, player.y, player.width, player.height);
    } else {
        ctx.fillStyle = player.color;
        ctx.fillRect(player.x, player.y, player.width, player.height);
    }
    ctx.restore();
}

function drawBullets() {
    bullets.forEach(bullet => {
        // Efeito de brilho
        const gradient = ctx.createRadialGradient(
            bullet.x + bullet.width/2, bullet.y + bullet.height/2, 0,
            bullet.x + bullet.width/2, bullet.y + bullet.height/2, bullet.width * 2
        );
        gradient.addColorStop(0, BULLET_COLOR);
        gradient.addColorStop(1, 'transparent');
        
        ctx.fillStyle = gradient;
        ctx.fillRect(bullet.x - bullet.width, bullet.y - bullet.height, 
                    bullet.width * 3, bullet.height * 3);
        
        // Tiro central
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(bullet.x, bullet.y, bullet.width, bullet.height);
    });
}

function drawEnemies() {
    enemies.forEach(enemy => {
        const enemyImg = enemyImages[enemy.imageIndex];
        if (enemyImg && enemyImg.loaded) {
            ctx.save();
            
            // Adiciona brilho ao redor do inimigo
            const gradient = ctx.createRadialGradient(
                enemy.x + enemy.width/2, enemy.y + enemy.height/2, 0,
                enemy.x + enemy.width/2, enemy.y + enemy.height/2, enemy.width/1.5
            );
            gradient.addColorStop(0, 'rgba(255, 100, 255, 0.2)');
            gradient.addColorStop(1, 'transparent');
            ctx.fillStyle = gradient;
            ctx.fillRect(enemy.x - 5, enemy.y - 5, enemy.width + 10, enemy.height + 10);
            
            // Desenha o inimigo com rotação
            ctx.translate(enemy.x + enemy.width/2, enemy.y + enemy.height/2);
            if (enemy.rotation) {
                ctx.rotate(enemy.rotation);
            }
            ctx.drawImage(enemyImg.img, -enemy.width/2, -enemy.height/2, 
                         enemy.width, enemy.height);
            ctx.restore();
        }
    });
}

// --- NOVO: Funções de Partículas (Explosão) ---
function createExplosion(x, y) {
    for (let i = 0; i < PARTICLE_COUNT; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * PARTICLE_SPEED + 1;
        particles.push({
            x,
            y,
            dx: Math.cos(angle) * speed,
            dy: Math.sin(angle) * speed,
            radius: Math.random() * 3 + 1,
            // Tons de laranja/amarelo com transparência variada
            color: `rgba(${255}, ${100 + Math.random() * 155}, ${0}, ${Math.random() * 0.5 + 0.5})`, 
            life: PARTICLE_LIFE
        });
    }
}

function updateParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.dx;
        p.y += p.dy;
        p.life--;
        // Efeito de gravidade leve (opcional)
        // p.dy += 0.05; 
        if (p.life <= 0) {
            particles.splice(i, 1);
        }
    }
}

function drawParticles() {
    ctx.save();
    particles.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.restore();
}
// --- Fim das Funções de Partículas ---


// --- NOVO: Funções do Fundo de Estrelas ---
function createStars() {
    for (let i = 0; i < STAR_COUNT; i++) {
        stars.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            radius: Math.random() * 1.5 + 0.5, // Tamanhos variados
            speed: Math.random() * 2 + 0.5 // Velocidades variadas
        });
    }
}

function updateStars() {
    stars.forEach(star => {
        star.y += star.speed;
        if (star.y > canvas.height) {
            star.y = 0;
            star.x = Math.random() * canvas.width;
        }
    });
}

function drawStars() {
    ctx.save();
    ctx.fillStyle = '#ffffff';
    stars.forEach(star => {
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        // Efeito de brilho (piscar)
        ctx.globalAlpha = Math.random() * 0.5 + 0.5; 
        ctx.fill();
    });
    ctx.restore();
}
// --- Fim das Funções de Estrelas ---

function drawScore() {
    ctx.save();
    ctx.shadowColor = SCORE_COLOR;
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px "Courier New"';
    ctx.fillText(`Pontos: ${score}`, 20, 40);
    ctx.restore();
}

function drawGameOver() {
    // Fundo com gradiente
    const gradient = ctx.createRadialGradient(
        canvas.width/2, canvas.height/2, 0,
        canvas.width/2, canvas.height/2, canvas.width/2
    );
    gradient.addColorStop(0, 'rgba(0, 0, 0, 0.9)');
    gradient.addColorStop(1, 'rgba(0, 0, 0, 0.7)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Texto com efeitos
    ctx.save();
    ctx.shadowColor = '#ff66cc';
    ctx.shadowBlur = 15;
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 52px "Courier New"';
    ctx.textAlign = 'center';
    ctx.fillText('FIM DE JOGO', canvas.width/2, canvas.height/2 - 30);
    
    ctx.shadowBlur = 10;
    ctx.font = 'bold 32px "Courier New"';
    ctx.fillText(`Pontuação Final: ${score}`, canvas.width/2, canvas.height/2 + 20);
    
    ctx.shadowBlur = 5;
    ctx.font = '20px "Courier New"';
    ctx.fillText('Pressione F5 para jogar novamente', canvas.width/2, canvas.height/2 + 70);
    ctx.restore();
}

// --- Funções de Lógica e Movimento ---
function clearCanvas() {
    // MODIFICADO: Preenche com preto sólido
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function updatePlayerPosition() {
    player.x += player.dx;
    player.y += player.dy;

    if (player.x < 0) player.x = 0;
    if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
    if (player.y < 0) player.y = 0;
    if (player.y + player.height > canvas.height) player.y = canvas.height - player.height;
}

function updateBullets() {
    for (let i = bullets.length - 1; i >= 0; i--) {
        bullets[i].y -= bulletSpeed;
        if (bullets[i].y < 0) bullets.splice(i, 1);
    }
}

function spawnEnemy() {
    const size = MIN_ENEMY_SIZE + Math.random() * (MAX_ENEMY_SIZE - MIN_ENEMY_SIZE);
    const x = Math.random() * (canvas.width - size);
    const y = -size;
    const imageIndex = Math.floor(Math.random() * enemyImages.length);
    
    enemies.push({ 
        x, 
        y, 
        width: size, 
        height: size,
        imageIndex,
        rotation: 0
    });
}

function updateEnemies() {
    enemies.forEach(enemy => {
        enemy.y += enemySpeed;
        enemy.rotation = (enemy.rotation || 0) + 0.02;
    });
    
    // Remove inimigos que saíram da tela
    for (let i = enemies.length - 1; i >= 0; i--) {
        if (enemies[i].y > canvas.height) {
            enemies.splice(i, 1);
        }
    }
}

function checkCollisions() {
    // Colisão Bala vs Inimigo
    for (let i = bullets.length - 1; i >= 0; i--) {
        for (let j = enemies.length - 1; j >= 0; j--) {
            const bullet = bullets[i];
            const enemy = enemies[j];

            if (bullet && enemy &&
                bullet.x < enemy.x + enemy.width &&
                bullet.x + bullet.width > enemy.x &&
                bullet.y < enemy.y + enemy.height &&
                bullet.y + bullet.height > enemy.y
            ) {
                sounds.explosao.currentTime = 0;
                sounds.explosao.play();
                
                // *** NOVO: ADICIONA EXPLOSÃO VISUAL ***
                createExplosion(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2);
                
                bullets.splice(i, 1);
                enemies.splice(j, 1);
                score += 10;
                break;
            }
        }
    }

    // Colisão Jogador vs Inimigo
    enemies.forEach(enemy => {
        if (player.x < enemy.x + enemy.width &&
            player.x + player.width > enemy.x &&
            player.y < enemy.y + enemy.height &&
            player.y + player.height > enemy.y
        ) {
            sounds.gameOver.play();
            
            // *** NOVO: ADICIONA EXPLOSÃO DO JOGADOR ***
            createExplosion(player.x + player.width / 2, player.y + player.height / 2);
            // Oculta o jogador para que a explosão seja visível
            player.width = 0; 
            
            gameOver = true;
        }
    });
}

// --- Loop Principal do Jogo ---
function gameLoop() {
    if (gameOver) {
        drawGameOver();
        // NOVO: Continua desenhando as partículas da explosão final
        updateParticles(); 
        drawParticles(); 
        return;
    }

    clearCanvas();
    
    // *** NOVO: ATUALIZA NOVOS ELEMENTOS ***
    updateStars();
    updateParticles();
    
    updatePlayerPosition();
    updateBullets();
    updateEnemies();
    checkCollisions();
    
    // *** NOVO: DESENHA NOVOS ELEMENTOS ***
    drawStars(); // Desenha estrelas primeiro (fundo)
    
    drawPlayer();
    drawBullets();
    drawEnemies();
    
    drawParticles(); // Desenha partículas (explosões) por cima de tudo
    
    drawScore();

    requestAnimationFrame(gameLoop);
}

// --- Controles ---
function keyDown(e) {
    if (e.key === 'ArrowRight' || e.key === 'Right') {
        player.dx = player.speed;
    } else if (e.key === 'ArrowLeft' || e.key === 'Left') {
        player.dx = -player.speed;
    } else if (e.key === 'ArrowUp' || e.key === 'Up') {
        player.dy = -player.speed;
    } else if (e.key === 'ArrowDown' || e.key === 'Down') {
        player.dy = player.speed;
    } else if (e.code === 'Space') {
        sounds.tiro.currentTime = 0;
        sounds.tiro.play();
        
        bullets.push({
            x: player.x + player.width/2 - BULLET_SIZE/2,
            y: player.y,
            width: BULLET_SIZE,
            height: BULLET_SIZE * 1.5
        });
    }
}

function keyUp(e) {
    if (e.key === 'ArrowRight' || e.key === 'Right' ||
        e.key === 'ArrowLeft' || e.key === 'Left') {
        player.dx = 0;
    }
    if (e.key === 'ArrowUp' || e.key === 'Up' ||
        e.key === 'ArrowDown' || e.key === 'Down') {
        player.dy = 0;
    }
}

document.addEventListener('keydown', keyDown);
document.addEventListener('keyup', keyUp);

// --- Início do Jogo ---
createStars(); // *** NOVO: Inicializa as estrelas ***
setInterval(spawnEnemy, 2000);
gameLoop();